'''
Test string in __init__
'''

from .prime import prime
from .primesh import primesh

__version__ = '0.5.0'