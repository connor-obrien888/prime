"""
.. include:: mainpage.md
"""

from .prime import prime
from .primesh import primesh